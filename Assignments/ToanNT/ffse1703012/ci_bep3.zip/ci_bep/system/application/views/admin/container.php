<?php
$this->load->view($this->config->item('backendpro_template_admin') . 'header');
$this->load->view($this->config->item('backendpro_template_admin') . 'content');
$this->load->view($this->config->item('backendpro_template_admin') . 'footer');
?>
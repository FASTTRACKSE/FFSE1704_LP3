<div id="footer" style="color: cornsilk">
        <div style="background-color: black">
          <div class="row">
            <br>
            <div class="col-md-3">
              <img style="padding-left:25px" src="http://localhost/codeigniter/assets/images/fasttrack-title-logo-white-new-1.png"  alt="the-brains"><br>
              <p></p><br>
              <span class="glyphicon glyphicon-earphone" class="footertext" style="padding-left: 25px">   0935793731</span><br>
              <p class="glyphicon glyphicon-envelope" class="footertext" style="padding-left: 25px">  contact@fasttrack.edu.vn<br><br>
                <i class="fa fa-facebook-official" style="font-size:24px; color:deepskyblue"></i>
                <i class="fa fa-youtube" style="font-size:24px; color: red"></i>
              </div> 
              <div class="col-md-3">
                <center>
                  <img src="http://localhost/codeigniter/assets/images/Owner.png" class="img-circle" width="55" height="55">
                  <br>
                  <h4 class="footertext">Chủ sở hữu</h4>
                  <a href="thongtinchudautu.html"><p class="footertext"><img src="http://localhost/codeigniter/assets/images/fasttrack-title-logo-color-new-1.png"><br></a> 
                  </center>
                </div>
                <div class="col-md-3">
                  <center>
                    <img src="http://oi61.tinypic.com/307n6ux.jpg" class="img-circle" alt="...">
                    <br>
                    <h4 class="footertext">Hỗ Trợ</h4>
                    <p class="footertext">Team 1<br>
                      <p class="fottertext">Mentors<br>
                      </center>
                    </div>
                    <div class="col-md-3">
                      <center>      
                        <img src="http://oi60.tinypic.com/w8lycl.jpg" class="img-circle" alt="the-brains">
                        <br>
                        <h4 class="footertext">Tác giả</h4>
                        <p class="footertext">Ngô Thế Toàn</p>
                        <p class="footertext">ffse1703012@st.fasttrack.edu.vn</p>
                      </center>
                    </div>
                  </div>
                  <div class="row">
                    <p><center><a href="thongtinlienhe.html">Contact Us</a> <p class="footertext">Copyright 2017 DanangTravel.com All right service</p></center></p>
                  </div>
                </div>
              </div>
            </body>
            </html>
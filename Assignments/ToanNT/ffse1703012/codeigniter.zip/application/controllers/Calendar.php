<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar extends CI_Controller {
	public function __construct() {
		Parent::__construct();
		$this->load->helper('url');
		$this->load->model("Calendar_model");
}
	public function index()
	{
		$this->load->view('calendar');
	}
    public function danhsach()
    {
        $this->load->view('danhsach');
    }
public function get_events() 
	{
		$start =$this->input->get("start");
		$end = $this->input->get("end");

        $startdt = new DateTime('now'); 
        $startdt->setTimestamp($start); 
        $format = $startdt->format('Y-m-d');

        $enddt = new DateTime('now'); 
        $enddt->setTimestamp($end); 
        $format2 = $enddt->format('Y-m-d');

        $events = $this->Calendar_model->get_events($format, 
        	$format2);

        $data_events = array();

        foreach($events->result() as $r) { 

        	$data_events[] = array(
        		"id" => $r->ID,
        		"tieu_de" => $r->title,
        		"mo_ta" => $r->description,
        		"ket_thuc" => $r->end,
        		"bat_dau" => $r->start
        	);
        }

        echo json_encode(array("events" => $data_events));
        exit();
    }
}


 ?>
<?php
require_once "templates/index-header.php";
?>
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block">
			<div id="main-content" class="col-2-3">
				<div class="wrap-col">
					<article>
						<div class="heading">
							<h2><a href="#">Bai viet 1</a></h2>
							<div class="info"> <a href="#"></a></div>
						</div>
						<div class="content">
							<img src="images/300x300.jpg"/>
							<p>L</p>
							<p></p>
							<p class="more"><a class="button" href="#">Read more</a></p>
						</div>
					</article>
					<article>
						<div class="heading">
							<h2><a href="#">Bai viet 2</a></h2>
							<div class="info"> <a href="#"></a></div>
						</div>
						<div class="content">
							<img src="images/300x300.jpg"/>
							<p>L</p>
							<p></p>
							<p class="more"><a class="button" href="#">Read more</a></p>
						</div>
					</article>
					<article>
						<div class="heading">
							<h2><a href="#">Bai viet 3 </a></h2>
							<div class="info"> <a href="#"></a></div>
						</div>
						<div class="content">
							<img src="images/300x300.jpg"/>
							<p>L</p>
							<p></p>
							<p class="more"><a class="button" href="#">Read more</a></p>
						</div>
					</article>

					
				</div>
			</div>
		</div>
	</div>
</section>
<?php 
require_once "templates/index-footer.php";
?>
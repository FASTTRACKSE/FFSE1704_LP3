<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-02-01 07:47:52 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 07:48:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:48:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:48:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:49:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:50:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:57:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:95) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 07:58:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:83) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:03:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:03:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:03:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:05:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:05:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:06:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:07:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:07:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:07:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:07:55 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 73
ERROR - 2010-02-01 08:07:55 --> Severity: Warning  --> unlink(C:\xampp\htdocs\ci_bep/system/cache/98dce83da57b0395e163467c9dae521b) [<a href='function.unlink'>function.unlink</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 74
ERROR - 2010-02-01 08:07:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:07:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:85) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:08:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:97) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:13:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:89) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:13:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:101) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:13:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:101) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:13:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:101) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:13:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:89) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:24:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:101) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 08:24:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\messages\controllers\admin.php:89) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 14:15:32 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 14:15:41 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:15:41 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:28:39 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:28:39 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:29:11 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:29:11 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:29:53 --> BackendPro->Bep_Assets->_is_loadable : Cannot find any asset with given name : master
ERROR - 2010-02-01 14:29:54 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:29:54 --> 404 Page Not Found --> 
ERROR - 2010-02-01 14:30:05 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:30:05 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:30:12 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:30:12 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:30:59 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:30:59 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:31:22 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:31:22 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:31:43 --> 404 Page Not Found --> acl_resources/admin
ERROR - 2010-02-01 14:31:43 --> 404 Page Not Found --> acl_resources/admin
ERROR - 2010-02-01 14:32:41 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:32:41 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:37:19 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:37:19 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 14:38:11 --> 404 Page Not Found --> acl_permissions/admin
ERROR - 2010-02-01 14:38:11 --> 404 Page Not Found --> acl_permissions/admin
ERROR - 2010-02-01 14:38:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\auth\controllers\admin\acl_permissions.php:286) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 14:38:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\modules\auth\controllers\admin\acl_permissions.php:286) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 14:39:55 --> BackendPro->Bep_Assets->_is_loadable : Cannot find any asset with given name : master
ERROR - 2010-02-01 14:39:55 --> Query error: Table 'ci_bep.eventcal' doesn't exist
ERROR - 2010-02-01 14:55:44 --> BackendPro->Bep_Assets->_is_loadable : Cannot find any asset with given name : master
ERROR - 2010-02-01 14:55:45 --> BackendPro->Bep_Assets->_is_loadable : Cannot find any asset with given name : master
ERROR - 2010-02-01 14:55:45 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 14:55:45 --> BackendPro->Bep_Assets->_is_loadable : Cannot find any asset with given name : master
ERROR - 2010-02-01 14:55:45 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:45:32 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 15:45:32 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:45:35 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 15:45:35 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:45:42 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 15:45:42 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:45:46 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:45:46 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 15:48:13 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 15:48:13 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:48:23 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 15:48:23 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: time C:\xampp\htdocs\ci_bep\modules\calendar\controllers\admin.php 18
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: time C:\xampp\htdocs\ci_bep\modules\calendar\controllers\admin.php 23
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: time C:\xampp\htdocs\ci_bep\modules\calendar\controllers\admin.php 26
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: time C:\xampp\htdocs\ci_bep\modules\calendar\controllers\admin.php 29
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: time C:\xampp\htdocs\ci_bep\modules\calendar\controllers\admin.php 32
ERROR - 2010-02-01 16:24:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 16:24:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 16:24:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 16:24:17 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 16:24:17 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:26:45 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:26:46 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 16:26:46 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:28:05 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:28:05 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 16:28:05 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 16:29:11 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:33:07 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:33:09 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:35:22 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:35:28 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:35:35 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:35:38 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:35:42 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:36:34 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:42:41 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:43:43 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:43:44 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:43:45 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:05 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:06 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:23 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:24 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:39 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: current_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 28
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: total_rows C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 43
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 109
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: previous_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 112
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_month C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_month_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 118
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_year C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:40 --> Severity: Notice  --> Undefined variable: next_year_text C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 121
ERROR - 2010-02-01 16:44:52 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:45:48 --> Severity: Notice  --> Undefined variable: members C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_home.php 130
ERROR - 2010-02-01 16:49:43 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 16:51:09 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 16:58:40 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:01:32 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:01:33 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 73
ERROR - 2010-02-01 17:01:33 --> Severity: Warning  --> unlink(C:\xampp\htdocs\ci_bep/system/cache/70efdf2ec9b086079795c442636b55fb) [<a href='function.unlink'>function.unlink</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 74
ERROR - 2010-02-01 17:01:45 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:01:46 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 73
ERROR - 2010-02-01 17:01:46 --> Severity: Warning  --> unlink(C:\xampp\htdocs\ci_bep/system/cache/f7177163c833dff4b38fc8d2872f1ec6) [<a href='function.unlink'>function.unlink</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 74
ERROR - 2010-02-01 17:06:26 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:11:19 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:22:50 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 17:22:59 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:23:03 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:24:18 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:25:28 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:26:15 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 17:26:16 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 17:29:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 17:29:28 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 17:29:28 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 17:29:47 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 17:29:47 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 17:32:29 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 17:32:29 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 17:32:34 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:35 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:47 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:53 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:54 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 17:40:54 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:54 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 17:40:54 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:40:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 17:40:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 17:40:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 17:40:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 17:40:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 17:40:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 17:41:02 --> 404 Page Not Found --> admin/update
ERROR - 2010-02-01 17:41:13 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:41:14 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 17:41:14 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:41:14 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 17:41:14 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 17:41:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 17:41:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 17:41:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 17:41:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 17:41:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 17:41:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:32:06 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 20:32:14 --> 404 Page Not Found --> 
ERROR - 2010-02-01 20:32:14 --> 404 Page Not Found --> 
ERROR - 2010-02-01 20:32:18 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:32:18 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:32:28 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:32:40 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:32:46 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:32:47 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:32:47 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:32:47 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:32:47 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:32:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:32:47 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:32:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:32:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:32:47 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:32:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:32:52 --> 404 Page Not Found --> admin/update
ERROR - 2010-02-01 20:33:14 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:15 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:33:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:15 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:33:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:33:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:33:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:33:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:33:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:33:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:33:20 --> 404 Page Not Found --> admin/update
ERROR - 2010-02-01 20:33:23 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:23 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:33:23 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:33:23 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:23 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:33:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:33:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:33:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:33:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:33:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:33:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:33:58 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:34:07 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:16 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:16 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:16 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:16 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:16 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:26 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:35:26 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:35:30 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:30 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:30 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:30 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:30 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:37 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:35:37 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:35:41 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:42 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:42 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:42 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:35:42 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:35:44 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:45 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:45 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:45 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:45 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:51 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:35:51 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:35:53 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:54 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:54 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:54 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:35:54 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:35:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:35:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:35:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:35:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:36:26 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:27 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:27 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:27 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:36:27 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:36:29 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:30 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:33 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:36:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:00 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:00 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:00 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:00 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:37:00 --> Severity: Notice  --> Undefined index:  username C:\xampp\htdocs\ci_bep\modules\calendar\views\admin\admin_calendar_mycal.php 33
ERROR - 2010-02-01 20:37:02 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:03 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:03 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:05 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:06 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:06 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:37:10 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:40 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:41 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:43:41 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:41 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:43:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:43:41 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:43:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:43:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:43:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:43:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:43:49 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:43:49 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:43:51 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:52 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:43:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:52 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:43:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:43:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:43:52 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:43:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:43:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:43:52 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:43:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:43:55 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 73
ERROR - 2010-02-01 20:43:55 --> Severity: Warning  --> unlink(C:\xampp\htdocs\ci_bep/system/cache/98dce83da57b0395e163467c9dae521b) [<a href='function.unlink'>function.unlink</a>]: No such file or directory C:\xampp\htdocs\ci_bep\system\codeigniter\Common.php 74
ERROR - 2010-02-01 20:44:10 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:44:21 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:44:28 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:44:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:44:29 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:44:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 20:44:29 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:44:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:44:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:44:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:44:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 20:44:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 20:44:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 20:44:32 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:44:32 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:55:37 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 20:55:44 --> 404 Page Not Found --> 
ERROR - 2010-02-01 20:55:44 --> 404 Page Not Found --> 
ERROR - 2010-02-01 20:55:48 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 20:55:48 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 20:58:30 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 20:58:38 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 20:58:43 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:03:46 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:03:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:37 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:39 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:47 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:48 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:04:48 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:48 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:04:48 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:04:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:04:48 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:04:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:04:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:04:48 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:04:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:04:59 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:09:39 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 21:09:56 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:09:56 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:06 --> 404 Page Not Found --> settings/admin
ERROR - 2010-02-01 21:10:06 --> 404 Page Not Found --> settings/admin
ERROR - 2010-02-01 21:10:14 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:14 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:22 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:22 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:28 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:28 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:45 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:45 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:50 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:10:50 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:11:15 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:11:15 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:11:21 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:11:21 --> 404 Page Not Found --> 
ERROR - 2010-02-01 21:18:59 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-02-01 21:19:12 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 21:19:12 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 21:19:16 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:21 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:22 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:19:22 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:19:22 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:22 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:19:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:19:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:19:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:19:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:19:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:19:31 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:32 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:19:32 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:19:32 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:32 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:19:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:19:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:19:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:19:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:19:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:19:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:19:35 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:20:30 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:20:32 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-02-01 21:21:50 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:21:50 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 120
ERROR - 2010-02-01 21:21:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:21:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:21:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:21:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:21:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:21:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:04 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:04 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:12 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 21:30:12 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 21:30:33 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:33 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:33 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:33 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:43 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-02-01 21:30:43 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 21:30:46 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:46 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\ci_bep\modules\calendar\models\mcalendar.php 69
ERROR - 2010-02-01 21:30:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Session.php 662
ERROR - 2010-02-01 21:30:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\ci_bep\system\application\libraries\Loader.php 929
ERROR - 2010-02-01 21:30:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:30:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_bep\system\libraries\Exceptions.php:166) C:\xampp\htdocs\ci_bep\system\libraries\Output.php 230
ERROR - 2010-02-01 21:42:52 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 21:42:52 --> 404 Page Not Found --> auth/admin
ERROR - 2010-02-01 21:45:31 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-02-01 21:45:31 --> 404 Page Not Found --> admin/AjaxgetCompletedBox

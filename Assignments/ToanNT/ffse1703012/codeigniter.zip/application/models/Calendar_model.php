<?php

class Calendar_model extends CI_Model 
{

    public function get_events($start, $end) 
    {
        return $this->db
            ->where("bat_dau", $start)
            ->where("ket_thuc", $end)
            ->get("ffse1703012_baiviet");
    }
   
}

?>
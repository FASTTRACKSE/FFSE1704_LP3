To {username},

Someone has requested a new password for your account with {site_name}. Here is your new login infomation:

Email: {email}
Password: {password}

Please make sure to login as soon as possible and change your password to something more memorable.

Many thanks from the {site_name} team.

{site_url}